SonicGrabber Pro 6.1 — standalone Linux build (x86_64)

RUN
  chmod +x SonicGrabber
  ./SonicGrabber
  (first start takes a few seconds while the single-file app unpacks)

NEEDS (system packages)
  ffmpeg   required   sudo apt install ffmpeg      (Fedora: RPM Fusion ffmpeg · Arch: pacman -S ffmpeg)
  mpv      optional   sudo apt install mpv         (in-app preview / playback)

YOUTUBE 403 ERRORS ("HTTP Error 403: Forbidden")
  YouTube now needs a JavaScript runtime (Deno). If none is found, a yellow "Fix YouTube downloads" button
  appears in the sidebar: click it and SonicGrabber downloads Deno (~40 MB) for you. Settings → Network &
  access shows the status. Manual alternative:  curl -fsSL https://deno.land/install.sh | sh

BROWSER COOKIES (optional, Settings → Network & access)
  Firefox works out of the box. Chrome/Chromium/Brave read their cookies through the system password
  keyring; if it is locked, SonicGrabber gives up after 35 s and carries on without cookies.

ADD TO APP MENU
  Open the app → Settings → Maintenance → Desktop launcher → Install

COMPATIBILITY
  Built on Ubuntu 24.04. Runs on distros with glibc 2.38+ (Ubuntu 24.04+, Mint 22, Fedora 39+,
  Debian 13, Arch/Manjaro). On older systems (Ubuntu 22.04, Mint 21, Debian 12) run build.sh instead:
  it builds the same program for your own machine:
      sudo apt install python3-venv python3-tk
      ./build.sh

UPDATING yt-dlp
  yt-dlp is bundled. When YouTube changes and downloads fail, get a fresh build (./build.sh pulls the
  newest yt-dlp), or run the script version: python3 main.py  (Settings → Update yt-dlp).

TROUBLESHOOTING
  ./SonicGrabber --selftest     checks every component and prints what is missing
  Logs: ~/.local/share/sonicgrabber/app.log    Crash report: ~/.local/share/sonicgrabber/crash.log
